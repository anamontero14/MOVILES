package com.example.elhostal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.room.Room
import com.example.elhostal.data.database.HabitacionesDatabase
import com.example.elhostal.data.database.ReservasDatabase
import com.example.elhostal.data.database.UsuarioLoggeadoDatabase
import com.example.elhostal.data.repositories.RepositoryHabitaciones
import com.example.elhostal.data.repositories.RepositoryReservas
import com.example.elhostal.data.repositories.RepositoryUsuarioLoggeado
import com.example.elhostal.ui.factory.AuthFactory
import com.example.elhostal.ui.factory.HabitacionFactory
import com.example.elhostal.ui.factory.ReservaFactory
import com.example.elhostal.ui.theme.ElHostalTheme
import com.example.elhostal.ui.viewmodels.VMAuth
import com.example.elhostal.ui.viewmodels.VMHabitacion
import com.example.elhostal.ui.viewmodels.VMReserva
import kotlin.getValue

class MainActivity : ComponentActivity() {

    //inicializacion de las bases de datos
    companion object {
        lateinit var databaseH: HabitacionesDatabase;
        lateinit var databaseR: ReservasDatabase;
        lateinit var databaseU: UsuarioLoggeadoDatabase
    }

    //Añade una variable que cargue el repositorio en modo Lazy (lateinit o lazy)
    private val repositoryHabitaciones by lazy { RepositoryHabitaciones(databaseH.habitacionDAO()) }
    private val repositoryReservas by lazy { RepositoryReservas(databaseR.reservaDao()) }
    private val repositoryUsuarioLoggeado by lazy { RepositoryUsuarioLoggeado(databaseU.usuarioLoggeadoDAO()) }

    //Instanciamos el ViewModel
    private val vmHabitacion: VMHabitacion by viewModels {
        //JugadasFactory(repositoryJugadas)
        HabitacionFactory(repositoryHabitaciones, repositoryReservas)
    }

    private val vmReserva: VMReserva by viewModels {
        ReservaFactory(repositoryReservas)
    }

    private val vmAuth: VMAuth by viewModels {
        AuthFactory(repositoryUsuarioLoggeado)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        databaseH = Room.databaseBuilder(
            applicationContext,                        // Contexto de la aplicación
            HabitacionesDatabase::class.java,// Clase de la base de datos
            "HabitacionesDatabase"            // Nombre de la base de datos
        ).build()                                    // Se construye
        databaseR = Room.databaseBuilder(
            applicationContext,                        // Contexto de la aplicación
            ReservasDatabase::class.java,    // Clase de la base de datos
            "ReservasDatabase"                // Nombre de la base de datos
        ).build()                                    // Se construye
        databaseU = Room.databaseBuilder(
            applicationContext,                               // Contexto de la aplicación
            UsuarioLoggeadoDatabase::class.java,    // Clase de la base de datos
            "UsuarioLoggeadoDatabase"               // Nombre de la base de datos
        ).build()                                           // Se construye

        enableEdgeToEdge()
        setContent {
            ElHostalTheme() {
                val navController = rememberNavController()
                NavHost(
                    navController = navController,
                    startDestination = "V1Bienvenida"
                ) {
                    composable("V1Bienvenida") {
                        /*Bienvenida(
                            navController,
                            viewmodel
                        )*/
                    }
                    composable("V2Juego/{nombreJugador}") { backStackEntry ->
                        /*val nombreJugador = backStackEntry.arguments?.getString("nombreJugador")

                        if (nombreJugador != null) {
                            Juego(
                                nombreJugador,
                                navController,
                                viewmodel
                            )
                        }*/
                    }
                    composable("V3Resultado") {
                        /*Resultados(
                            viewmodel,
                            navController
                        )*/
                    }
                }
            }
        }
    }
}